package org.metaworks.test.faceclass;




public class Competency2{

	public Competency2(String string) {
		setName(string);
	}
	
	String name;

		public String getName() {
			return name;
		}
	
		public void setName(String name) {
			this.name = name;
		}
	
}